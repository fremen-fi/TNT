# TNT Refactor - Migration Guide

## New Module Path

```
module github.com/fremen-fi/tnt/go
```

## Files That STAY (keep these, update imports)

```
go/ui.go                   # setupUI, loadPreferences, savePreferences, etc.
go/freq_anal.go            # analyzeFrequencyResponseBands, buildEqFilter, etc.
go/ui_darwin.go            # getPlatformFormats, getPlatformCodecMap (darwin)
go/ui_windows.go           # getPlatformFormats, getPlatformCodecMap (windows)
go/ui_linux.go             # getPlatformFormats, getPlatformCodecMap (linux)
go/bundled.go              # fyne bundle generated resources
```

## Files to DELETE (replaced by new packages)

```
go/ffmpeg_mac.go           # Replaced by platform/ffmpeg_darwin_arm64.go
go/ffmpeg_mac_amd64.go     # Replaced by platform/ffmpeg_darwin_amd64.go  
go/ffmpeg_windows.go       # Replaced by platform/ffmpeg_windows.go
go/ffmpeg_linux_amd64.go   # Replaced by platform/ffmpeg_linux_amd64.go
go/ffmpeg_linux_arm.go     # Replaced by platform/ffmpeg_linux_arm64.go
go/syscall_windows.go      # Replaced by platform/syscall_windows.go
go/syscall_unix.go         # Replaced by platform/syscall_unix.go
go/dynscore.go             # Merged into internal/audio/
go/dyn_norm.go             # Merged into internal/audio/
```

## New Directory Structure

```
go/
├── main.go                    # REPLACED - use new version
├── go.mod                     # REPLACED - updated module path
├── go.sum                     # Keep existing (will update with go mod tidy)
├── bundled.go                 # Keep as-is
├── ui.go                      # Keep, update imports
├── freq_anal.go               # Keep, update imports
├── ui_darwin.go               # Keep as-is
├── ui_windows.go              # Keep as-is
├── ui_linux.go                # Keep as-is
│
├── internal/
│   ├── audio/
│   │   ├── types.go           # DynamicsAnalysis, FrequencyBandAnalysis, etc.
│   │   ├── parsing.go         # ParseAstatsOutput, ParseDynamicsScore, etc.
│   │   ├── compression.go     # GetCompressionModifiers, GetBaseRatioFromCrest, etc.
│   │   └── dynaudnorm.go      # CalculateDynaudnormParams, BuildDynaudnormFilter
│   │
│   ├── config/
│   │   ├── codecs.go          # CodecMap (consolidated from all platform files)
│   │   └── process.go         # ProcessConfig struct
│   │
│   └── ffmpeg/
│       └── runner.go          # Path, Command(), Run() - wraps exec.Command
│
├── platform/
│   ├── ffmpeg_darwin_arm64.go # //go:build darwin && arm64
│   ├── ffmpeg_darwin_amd64.go # //go:build darwin && amd64
│   ├── ffmpeg_windows.go      # //go:build windows
│   ├── ffmpeg_linux_amd64.go  # //go:build linux && amd64
│   ├── ffmpeg_linux_arm64.go  # //go:build linux && arm64
│   ├── syscall_windows.go     # HideWindow() for Windows
│   └── syscall_unix.go        # HideWindow() no-op for Unix
│
├── buildBlocks/               # Keep as-is
└── ffmpegSource/              # Keep as-is (or move to platform/)
```

## Quick Start

1. Extract zip to your `go/` directory
2. Delete old files listed above  
3. Update `ui.go` and `freq_anal.go` imports (see below)
4. Move `ffmpegSource/` into `platform/ffmpegSource/`
5. Run `go mod tidy`

## Required Updates to Files That Stay

### ui.go

Add import:
```go
import (
    // existing imports...
    "github.com/fremen-fi/tnt/go/internal/ffmpeg"
)
```

Replace all occurrences:
- `exec.Command(ffmpegPath, ...)` → `ffmpeg.Command(...)`
- `hideWindow(cmd)` → (remove, handled by ffmpeg.Command)

### freq_anal.go

Add import:
```go
import (
    // existing imports...
    "github.com/fremen-fi/tnt/go/internal/ffmpeg"
)
```

Replace:
- `exec.Command(ffmpegPath, ...)` → `ffmpeg.Command(...)`
- `hideWindow(cmd)` → (remove)

### All files using ProcessConfig

The struct is now `config.ProcessConfig` with exported fields:
- `writeTags` → `WriteTags`
- `noTranscode` → `NoTranscode`
- `originIsAAC` → `OriginIsAAC`
- `bypassProc` → `BypassProc`
- `dataCompLevel` → `DataCompLevel`

## Benefits

1. **No more duplication**: codecMap defined once in config/codecs.go
2. **Testable units**: audio parsing/calculation functions can be unit tested
3. **Clear separation**: platform code, audio logic, config, and UI are separated
4. **Maintainable**: smaller files, each with single responsibility
5. **Reusable**: audio package could be used by other tools
